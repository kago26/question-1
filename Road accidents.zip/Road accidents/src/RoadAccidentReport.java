import java.util.Scanner;
//ST10450310
public class RoadAccidentReport {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Arrays of Cities and Accidents
        String[] cities = {"Cape Town", "Johannesburg", "Port Elizabeth"};
        int[][] accidents = new int[cities.length][2]; // [][0] for car, [][1] for motorbike

        // Input data for each city
        for (int i = 0; i < cities.length; i++) {
            System.out.print("Enter the number of car accidents for " + cities[i] + ": ");
            accidents[i][0] = scanner.nextInt();
            System.out.print("Enter the number of motorbike accidents for " + cities[i] + ": ");
            accidents[i][1] = scanner.nextInt();
        }

        // Display report
        System.out.println("-----------------------------------------------------------------------------------------------------------");
        System.out.println("Road Accident Report");
        System.out.println("-----------------------------------------------------------------------------------------------------------");
        System.out.printf("%-25s %-25s %-25s%n", "City", "Car", "Motor Bike");
        
        int[] totals = new int[cities.length]; // Store total accidents for each city
        for (int i = 0; i < cities.length; i++) {
            System.out.printf("%-25s %-25d %-25d%n", cities[i], accidents[i][0], accidents[i][1]);
            totals[i] = accidents[i][0] + accidents[i][1]; // Calculation of total accidents for each city
        }

        System.out.println("-----------------------------------------------------------------------------------------------------------");
        System.out.println("Road Accident Totals For Each City");
        System.out.println("-----------------------------------------------------------------------------------------------------------");
        for (int i = 0; i < cities.length; i++) {
            System.out.printf("%-25s %-25d%n", cities[i], totals[i]);
        }

        // Search for the city with the highest number of accidents
        int maxIndex = 0;
        for (int i = 1; i < totals.length; i++) {
            if (totals[i] > totals[maxIndex]) {
                maxIndex = i;
            }
        }

        System.out.println("City With The Most Vehicle Accidents: " + cities[maxIndex]);
        System.out.println("-----------------------------------------------------------------------------------------------------------");

        scanner.close();
    }
}

